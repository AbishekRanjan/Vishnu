package luma_clothing_site;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.runners.Parameterized.Parameter;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.opera.OperaOptions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;

public class Luma_ {
	public WebDriver driver;
	public static boolean pass = true;
	ExtentSparkReporter report;
	ExtentReports extent;
	ExtentTest test;
	public static String baseUrl = "https://magento.softwaretestingboard.com";
	Logger log = Logger.getLogger("devpinoyLogger");
	
	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) {
	
//the path for the extent report
		String path = ("C:\\Users\\joel.antony\\eclipse-workspace\\Automation_project_Final\\test-output\\extentReports.html");
		report = new ExtentSparkReporter(path);
		extent = new ExtentReports();
		extent.attachReporter(report);
		test = extent.createTest("Project Luma Automation testing");
		
//driver path
		// cross browser testing
		if (browser.equalsIgnoreCase("opera")) {
			//launch opera driver
			System.setProperty("webdriver.opera.driver",
					"C:\\Users\\joel.antony\\OneDrive - HCL Technologies Ltd\\Documents\\Desktop\\selenium testing\\operadriver_win64\\operadriver_win64\\operadriver.exe");
			driver = new OperaDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			//launch chrome driver
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\joel.antony\\OneDrive - HCL Technologies Ltd\\Documents\\Desktop\\selenium testing\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
	}
	
	@Test
	public void customerlogin() throws InterruptedException, IOException {
//log4j
		test.info("browser launched");
		log.info("browser opened");
		test.info("window maximized");
		log.info("window max sized");
//URL of the Web-site
		driver.get(baseUrl);
		Thread.sleep(2000);
		test.pass("url opened");
		log.info("url opened");
//New customer account module 
		driver.navigate().to("https://magento.softwaretestingboard.com/customer/account/create/");
		if (driver.findElement(By.xpath("/html/body/div[2]/header/div[1]/div/ul/li[3]/a")).isDisplayed()) {
			test.info("Login Page is Displayed");
			log.info("Login displayed");
			Assert.assertEquals(true, true);
		} else {
			test.fail("Not displayed");
			log.info("Not displayed");
			Assert.assertEquals(true, false);
		}
		

//path for Apache POI
		FileInputStream fis = new FileInputStream(new File(
				"C:\\Users\\joel.antony\\OneDrive - HCL Technologies Ltd\\Documents\\Desktop\\Automation Project Final\\Luma_customer.xlsx"));
		XSSFWorkbook wrb = new XSSFWorkbook(fis);
		XSSFSheet sh = wrb.getSheet("Luma_customer");
		test.info("validating new customer login");
		log.info("creating new customer login");
		
// details for the new customer module
// first-name=naser, last-name= alasser, e-mail= (change every-time when you execute), pass= Nas+Tan123
		driver.findElement(By.id("firstname")).sendKeys(sh.getRow(1).getCell(2).getStringCellValue());
		driver.findElement(By.id("lastname")).sendKeys(sh.getRow(2).getCell(2).getStringCellValue());
		driver.findElement(By.id("is_subscribed")).click();
		driver.findElement(By.id("email_address")).sendKeys("naserlad171@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Nas+Tan123");
		driver.findElement(By.id("password-confirmation")).sendKeys("Nas+Tan123");
		test.pass("login passed");
		log.info("login passed");

		driver.findElement(By.xpath("/html/body/div[2]/main/div[3]/div/form/div/div[1]/button")).click();
	}
	
	@Test(dependsOnMethods = "customerlogin")
	public void men() throws InterruptedException {
		Thread.sleep(2000);
//men's module (hoodie)
		driver.navigate().to("https://magento.softwaretestingboard.com/men.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/men/tops-men/hoodies-and-sweatshirts-men.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/abominable-hoodie.html");
		Thread.sleep(1000);
		test.info("purchasing item-1");
		log.info("purchasing item-1");
		driver.findElement(By.id("option-label-size-143-item-168")).click();
		Thread.sleep(1000);
		test.info("size selected");
		log.info("size selected-1");
		driver.findElement(By.id("option-label-color-93-item-53")).click();
		Thread.sleep(1000);
		test.info("color selected");
		log.info("color selected-1");
		driver.findElement(By.id("qty")).click();
		driver.findElement(By.id("qty")).clear();
		driver.findElement(By.id("qty")).sendKeys("2");
		Thread.sleep(1000);
		test.info("quantity selected");
		log.info("quantity selected-1");
		driver.findElement(By.id("product-addtocart-button")).click();
		if (pass) {
			test.pass("item-1 added to the cart successfully");
			log.info("item-1 added");
		} else {
			test.fail("item not added");
			log.info("item not added");
		}

	}

	@Test(dependsOnMethods = "men")
	public void women() throws InterruptedException, AWTException {
		Thread.sleep(2000);
//women's module (jacket)
		driver.navigate().to("https://magento.softwaretestingboard.com/women.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/women/tops-women/jackets-women.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/juno-jacket.html");
		Thread.sleep(1000);
		test.info("purchasing item-2");
		log.info("purchasing item-2");
		driver.findElement(By.xpath("//*[@id=\"option-label-size-143-item-167\"]")).click();
		Thread.sleep(1000);
		test.info("size selected");
		log.info("size selected-2");
		driver.findElement(By.id("option-label-color-93-item-50")).click();
		Thread.sleep(2000);
		test.info("color selected");
		log.info("color selected-2");
		driver.findElement(By.id("qty")).click();
		driver.findElement(By.id("qty")).clear();
		driver.findElement(By.id("qty")).sendKeys("3");
		Thread.sleep(1000);
		test.info("quantity selected");
		log.info("quantity selected-2");
		driver.findElement(By.id("product-addtocart-button")).click();
		if (pass) {
			test.pass("item-2 added to the cart successfully");
			log.info("item-2 added");
		} else {
			test.fail("item not added");
			log.info("item not added");
		}
	}

	@Test(dependsOnMethods = "women")
	public void bag() throws InterruptedException {
//gear module (bag)
		driver.navigate().to("https://magento.softwaretestingboard.com/gear.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/gear/bags.html");
		driver.navigate().to("https://magento.softwaretestingboard.com/fusion-backpack.html");
		Thread.sleep(1000);
		test.info("purchasing item-3");
		log.info("purchasing item-3");
		driver.findElement(By.id("qty")).click();
		driver.findElement(By.id("qty")).clear();
		driver.findElement(By.id("qty")).sendKeys("1");
		Thread.sleep(1000);
		test.info("quantity selected");
		log.info("quantity selected-3");
		driver.findElement(By.id("product-addtocart-button")).click();
		Thread.sleep(1000);
		driver.navigate().to("https://magento.softwaretestingboard.com/checkout/cart/");
		test.pass("item-3 added to the cart successfully");
		log.info("item-3 added");
		if (pass) {
			test.pass("all 3 items added to the cart!");
			log.info("all 3 items added");
		} else {
			test.fail("items not added");
			log.info("items not added");
		}

	}

	@Test(dependsOnMethods = "bag")
	public void logout() throws InterruptedException, IOException {
		test.info("navigating to logout page..");
		log.info("logout page");
		Thread.sleep(3000);
//logout
		driver.navigate().to("https://magento.softwaretestingboard.com/customer/account/logout/");
		Thread.sleep(7000);
		test.pass("signed out");
		test.info("navigated to the home page");
		log.info("logged out");
//ScreenShot
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SourceFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(
				"C:\\Users\\joel.antony\\eclipse-workspace\\Automation_project_Final\\Screenshots\\Screenshot.png");
		Files.copy(SourceFile, DestFile);
	}

	@AfterTest
	public void exit() {
		extent.flush();
		driver.quit();
	}
}
