package projectatm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class connection {
	public static Connection connection() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	    String Url = "jdbc:oracle:thin:@localhost:1521/xe";
	    Connection conn = DriverManager.getConnection(Url, "Vishnu","P@ssw0rd");
	   
	    Statement stmt= conn.createStatement();
		return conn;
	}
}
