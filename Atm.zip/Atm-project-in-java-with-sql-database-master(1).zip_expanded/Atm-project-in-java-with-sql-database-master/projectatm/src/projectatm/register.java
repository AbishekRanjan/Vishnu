package projectatm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class register {
	public static void register() throws SQLException {
		 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		    String Url = "jdbc:oracle:thin:@localhost:1521/xe";
		    Connection conn = DriverManager.getConnection(Url, "Vishnu","P@ssw0rd");
		   
		    Statement stmt= conn.createStatement();
		    Scanner sc= new Scanner(System.in);
		    System.out.println("Welcome To Registration Page.....");
		    
		    System.out.println("Enter the id");
		    int id=sc.nextInt();
		    System.out.println("Enter the name");
		    String name=sc.next();
		    System.out.println("Enter the Email");
		    String email=sc.next();
		    System.out.println("Enter the Amount");
		    int cash=sc.nextInt();
		    System.out.println("Enter the ATM Card");
		    String AtmCard=sc.next();
		    System.out.println("Enter the PhoneNo");
		    String PhoneNo=sc.next();
ResultSet rs=stmt.executeQuery("insert into ATM values('"+id+"','"+name+"','"+email+"','"+cash+"','"+AtmCard+"','"+PhoneNo+"')");
	        System.out.println("Registered successfully!!!");
	}}