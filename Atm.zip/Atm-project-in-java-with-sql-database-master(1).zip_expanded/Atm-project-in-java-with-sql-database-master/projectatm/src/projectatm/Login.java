package projectatm;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.*;
	
public class Login  {

	public static void selectAll(String name, int password) throws IOException {
		Matcher match = null;
		Scanner in = new Scanner(System.in);
		String dbemail = null, dbname = null,dbcash = null,dbatmcard= null;
		int choice;
		String sql = "SELECT * FROM ATM WHERE id ='" + password + "' AND name ='" + name + "'";
		
		try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql)) {

			while (rs.next()) {

				dbname = rs.getString("name");
				dbcash = rs.getString("cash");
			dbatmcard = rs.getString("AtmCard");
				
				dbemail = rs.getString("email");

			}
			
				
				
			if (dbname == null || password == 0)
			{ main.login();
			System.out.println("login failed..");
			}else {System.out.println("\n\tlogin SuccessFull...");
			System.out.println("\tWelcome to Bank of universe");
			}
			while (true) {
				System.out.println(" Press 1 to check current balance");
				System.out.println(" Press 2 to withdraw");
				System.out.println(" Press 3 to Deposit");
				System.out.println(" Press 4 to change pin");
				System.out.println(" Press 5 for transaction");
				System.out.println(" Press 6 to logout");
				System.out.println(" Enter the choice:");
				choice = in.nextInt();

				if (choice == 1) {

					File file = new File("./current.txt");
					file.createNewFile();
					FileWriter fr = new FileWriter(file);

					try {

						fr.write("Name\t" + dbname + "\n");
						fr.write("Balance  \t " + dbcash + "\n");
						
						fr.write("AtmCard number\t" + dbatmcard + "\n");
						fr.write("Mailing-address\t  " + dbemail + "\n");
						fr.close();

					} catch (Exception e) {
						e.printStackTrace();
					}

					BufferedReader reader;

					try {

						reader = new BufferedReader(new FileReader(file));
						String line = reader.readLine();
						while (line != null) {
							System.out.println(line);
							line = reader.readLine();
						}
						System.out.println();
						reader.close();

					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if (choice == 2) {
					Double withdrawcash, newamount;
					System.out.println();
					System.out.println("How much cash you want to withdraw : ");
					int withdraw = in.nextInt();

					withdrawcash = Double.parseDouble(dbcash);
					newamount = withdrawcash - withdraw;

					File file = new File("./withdraw.txt");
					file.createNewFile();
					FileWriter fr = new FileWriter(file);

					try {

						fr.write("Name\t" + dbname + "\n");
						fr.write("Amount-deducted \t" + withdraw + "\n");
						fr.write("New-Balance  \t " + newamount + "\n");
						
						fr.write("AtmCard number\t" + dbatmcard + "\n");
						fr.write("Mailing-address\t  " + dbemail + "\n");
						fr.close();
						
					
						dbcash = Double.toString(newamount);
						try (Connection conn1 =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
								PreparedStatement pstmt = conn1.prepareStatement("UPDATE ATM SET cash ='"+dbcash+"'WHERE id = '"+password+"' ")) {

						pstmt.executeUpdate();
							
							
						} catch (SQLException e) {
							System.out.println(e.getMessage());
							
						}

					} catch (Exception e) {
						e.printStackTrace();
					}

					BufferedReader reader;

					try {

						reader = new BufferedReader(new FileReader(file));
						String line = reader.readLine();
						while (line != null) {
							System.out.println(line);
							line = reader.readLine();
						}
						System.out.println();
						reader.close();

					} catch (Exception e) {
						e.printStackTrace();
					}System.out.println(" WITHDRAWAL SUCCESSFULLY  DONE!!!!\n");

				}
				if (choice == 3) {
					Double ecash, newamount;
					System.out.println();
					System.out.println("How much amount you want to added : ");
					int deposit = in.nextInt();

					ecash = Double.parseDouble(dbcash);
					newamount = ecash + deposit;

					File file = new File("./withdraw.txt");
					file.createNewFile();
					FileWriter fr = new FileWriter(file);

					try {

						fr.write("Name\t" + dbname + "\n");
						fr.write("Amount-Added \t" + deposit+ "\n");
						fr.write("New-Balance  \t " + newamount + "\n");
						
						fr.write("AtmCard number\t" + dbatmcard+ "\n");
						fr.write("Mailing-address\t  " + dbemail + "\n");
						fr.close();
						
						dbcash = Double.toString(newamount);
					
						try (Connection conn1 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
								PreparedStatement pstmt = conn1.prepareStatement("UPDATE ATM SET cash ='" + dbcash + "'   WHERE id ='" + password + "'")) {

							pstmt.executeUpdate();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}

					} catch (Exception e) {
						e.printStackTrace();
					}

					BufferedReader reader;

					try {

						reader = new BufferedReader(new FileReader(file));
						String line = reader.readLine();
						while (line != null) {
							System.out.println(line);
							line = reader.readLine();
						}
						System.out.println();
						reader.close();

					} catch (Exception e) {
						e.printStackTrace();
					}
					System.out.println("\nDEPOSIT SUCCESSFULLY DONE !!!!");

				}
				
				if (choice == 4) {
					String newpass = null;
					System.out.print("Enter new 4 digit pin code : ");
					do {
						try {

							
							newpass = in.nextLine();
							Pattern pattern = Pattern.compile("\\d{4}$");
							match = pattern.matcher(newpass);
						} catch (Exception e) {
							System.out.println("Enter correct pin : ");
							break;
						}

					} while (match.matches() != true);

					int newpass1 = Integer.parseInt(newpass);

					String sql3 = "UPDATE ATM SET id ='" + newpass + "' WHERE id ='" + password + "'";

					try (Connection conn1 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
						PreparedStatement pstmt = conn1.prepareStatement(sql3)) {
						pstmt.executeUpdate();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
					System.out.println("\nPIN CODE UPDATED SUCCESSFULLY!!!!");
				}
				if (choice == 5) {
					while (true) {
						String acc = null, dbcreditnum1 = null, dbcash1 = null, tran = null;
						System.out.print("Enter amount for transaaction : ");
						do {
							try {
								
								tran = in.nextLine();

							} catch (Exception e) {
								System.out.println("Enter correct amount...");
								break;
							}
							Pattern pattern = Pattern.compile("[-+]?([0-9]*\\\\.[0-9]+|[0-9]+)");
							match = pattern.matcher(tran);

													} while (match.matches() == false);

						System.out.println();
						
						do {
							try {
								System.out.print("Enter correct Account number for transaaction :");
								acc = in.nextLine();
							} catch (Exception e) {
								System.out.println("Enter correct Atm card number...");
							}
							Pattern pattern = Pattern.compile(
									"^\\d{16}$");
							match = pattern.matcher(acc);

						} while (match.matches() == false );

						String sql1 = "SELECT * FROM ATM WHERE AtmCard ='" + acc + "'";

						try (Connection conn1 = connection.connection();
								Statement stmt1 = conn1.createStatement();
								ResultSet rs1 = stmt1.executeQuery(sql1)) {

							while (rs1.next()) {
								dbcash1 = rs1.getString("cash");
								dbcreditnum1 = rs1.getString("AtmCard");

							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						if (dbcreditnum1 == null)
							continue;

						Double dbcash2 = Double.parseDouble(dbcash1);
						dbcash2 = dbcash2 + Double.parseDouble(tran);
						String newcash = Double.toString(dbcash2);
						Double cash = Double.parseDouble(dbcash);
						cash = cash - Integer.parseInt(tran);

						dbcash = Double.toString(cash);

						String sql11 = "UPDATE ATM SET cash ='" + newcash + "' WHERE AtmCard ='"
								+ acc + "'";

						try (Connection conn1 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
								PreparedStatement pstmt = conn1.prepareStatement(sql11)) {

							pstmt.executeUpdate();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}

						String sql111 = "UPDATE ATM SET cash ='" + cash + "' WHERE AtmCard ='" + dbatmcard
								+ "'";

						try (Connection conn1 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "Vishnu","P@ssw0rd");
								PreparedStatement pstmt = conn1.prepareStatement(sql111)) {

							pstmt.executeUpdate();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}
						System.out.println("\nTRANSACTION SUCCESSFUL!!!!!");
						break;
					}
				}

				if (choice == 6) {
					
					System.out.println(" \t\tThank you for visiting!!!!!!       ");
					System.out.println("  May God be with you today and always! I Hope that You \n\t\t Have a Nice Day\n\t\tBank Of Universe.....");
					System.exit(0);
				}

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());

		}
	}
}