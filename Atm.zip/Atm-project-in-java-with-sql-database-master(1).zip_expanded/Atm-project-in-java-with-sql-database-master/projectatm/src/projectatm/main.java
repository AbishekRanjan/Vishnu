package projectatm;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.*;

public class main {

	public static void main(String[] args) throws IOException, SQLException {
		System.out.println("\t  Welcome To The Bank of Universe :-");
		System.out.println();
		String a;
		Scanner in = new Scanner(System.in);
		while (true) {
			System.out.printf("\t \t Press 1 to register\n\t \t Press 2 to login \n\t \t Press 3 to Logout \n \t\t Enter the choice: ");
			
			a = in.nextLine();
			if (a.equals("2")) {
				login();
			} else if (a.equals("1")) {
				register();
			} else if (a.equals("3"))
				Logout();
		
				
		}
	}
	

	private static void Logout() {
		// TODO Auto-generated method stub
		System.out.println(" \t\tThank you for visiting!!!!!!       ");
		System.out.println("  May God be with you today and always! I Hope that You \n\t\t Have a Nice Day \n\t\tBank Of Universe");
		System.exit(0);
		
	}


	public static void login() throws IOException, SQLException {
		
		
		
		 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		    String Url = "jdbc:oracle:thin:@localhost:1521/xe";
		    Connection conn = DriverManager.getConnection(Url, "Vishnu","P@ssw0rd");
		   
		    Statement stmt= conn.createStatement();
		
		
		Scanner in = new Scanner(System.in);
		String name, password = null;
		Matcher match = null;
		
		int pass;
		
		System.out.println("\tWelcome to the Login page.....");
		System.out.print("\nEnter your correct name : ");
		name = in.nextLine();

		do {
		
			try {

				System.out.print("Enter 4 digit pin code : ");
				password = in.nextLine();
				Pattern pattern = Pattern.compile("\\d{4}");
				match = pattern.matcher(password);
				 
				
				
			} catch (Exception e) {
				
				System.out.println("Enter correct pin : ");
				
				break;
			}
         
          
			
		}while(match.matches() != true) ;
		
		pass = Integer.parseInt(password);
		Login.selectAll(name, pass);	 
	}
		
	

	public static void register() throws IOException, SQLException {
		register.register();
		String cash = null, password = null, email = null, AtmCard = null,  number = null;
		Matcher match = null;
		
		Pattern ptr;
		Scanner in = new Scanner(System.in);
		int pass;

	
	
		
			
	}}

		